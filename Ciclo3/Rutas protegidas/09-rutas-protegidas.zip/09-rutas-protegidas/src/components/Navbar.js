import React from 'react'

export const Navbar = () => {

  return (
    <nav className="navbar navbar-light bg-light">
      <div className="container">
        <span className="navbar-brand">
          <h2>Rutas Protegidas</h2>
        </span>
      </div>

    </nav>
  )
}
