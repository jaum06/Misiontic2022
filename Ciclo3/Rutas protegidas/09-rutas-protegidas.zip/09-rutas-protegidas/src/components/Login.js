import React from 'react'

export const Login = () => {

  return (
    <div>
      <h3 className="text-center">Acceso Usuarios</h3>
      <div className="row justify-content-center">
        <div className="col-12 col-sm-8 col-md-6 col-xl-4">
          <form>
            <input
              type="text"
              placeholder="Ingresa tu email"
              className={`form-control mb-2 `}
            />

            (
            <div className="invalid-feedback mb-2">
              Error
            </div>
            )


            <input
              type="password"
              placeholder="Ingresa tu password"
              className={`form-control mb-2 `}
            />
            <div className="invalid-feedback mb-2">
              Error
            </div>

            <div className="d-grid gap-2">
              <button
                className="btn btn-outline-success">Ingresar</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
